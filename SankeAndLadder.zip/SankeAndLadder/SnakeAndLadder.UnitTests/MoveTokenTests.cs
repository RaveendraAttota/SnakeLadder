﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SankeAndLadder;

namespace SnakeAndLadder.UnitTests
{
    [TestClass]
    public class MoveTokenTests
    {
        MoveToken moveToken = new MoveToken();
        [TestMethod]
        public void MoveTokenByDice_ShouldBeMovedToCorrectPosition()
        {
            //Arrange
            int DiceResult = 3;
            int ExpectedPosition = 4;
            
            //Act
            int NewPosition = moveToken.MoveTokenByDice(DiceResult);

            //Assert
            Assert.AreEqual(NewPosition, ExpectedPosition);
        }
    }
}
