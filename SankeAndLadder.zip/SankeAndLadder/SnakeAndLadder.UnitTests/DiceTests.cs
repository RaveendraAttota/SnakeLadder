﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SankeAndLadder;

namespace SnakeAndLadder.UnitTests
{
    [TestClass]
    public class DiceTests
    {
        Dice dice = new Dice();

        [TestMethod]
        public void RollADie_ShouldBeBetween1And6Inclusive()
        {
            //Arrange
            int RollResult = 0;

            //Act
            RollResult = dice.RollADie();

            //Assert
            Assert.IsTrue((RollResult >= 1 && RollResult <= 6));

        }
    }
}
