I have just implemented methods that can be used as part of the game development and written
unit tests to test the methods. Thesee methods can be called by the other parts of the application

In the full scale implementation, I would have used Interfaces, Dependency Injection and IoC containers 
instead of making the dependency classes.