﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SankeAndLadder
{
    public class MoveToken
    {
        static int CurrentPosition = 1;
        static int NewPosition = 0;
        static bool IsWon;

        public int MoveTokenByDice(int RollResult)
        {
            NewPosition = CurrentPosition + RollResult;

            if(NewPosition > 100)
            {
                NewPosition = CurrentPosition;
            }
            else if(NewPosition == 100)
            {
                IsWon = true;
            }
            else
            {
                CurrentPosition = NewPosition;
            }

            return NewPosition;
        }
    }
}
