﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SankeAndLadder
{
    public class Dice
    {
        Random rnd = new Random();

        public int RollADie()
        {
            return rnd.Next(1, 7);
        }
    }
}
